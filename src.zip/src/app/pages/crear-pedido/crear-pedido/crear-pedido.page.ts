import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-crear-pedido',
  templateUrl: './crear-pedido.page.html',
  styleUrls: ['./crear-pedido.page.scss'],
})
export class CrearPedidoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
