import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agregar-pedido',
  templateUrl: './agregar-pedido.page.html',
  styleUrls: ['./agregar-pedido.page.scss'],
})
export class AgregarPedidoPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
