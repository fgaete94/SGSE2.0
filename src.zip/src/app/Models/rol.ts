export interface Rol {
    id: number;
    description: string;
  }