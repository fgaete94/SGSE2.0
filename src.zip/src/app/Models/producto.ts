export interface Producto{
    id: number;
    name: string;
    price: number;
    sku: number;
    deleted_at: Date;
    
}